import { useEffect, useRef, useState, type RefObject } from "react";
import { engine } from "@/lib/audio/engine";

export function usePlayhead() {
  const [time, setTime] = useState(() => engine.getPlayhead());
  useEffect(() => engine.subscribe(setTime), []);
  return time;
}

export function usePlaying() {
  const [playing, setPlaying] = useState(() => engine.playing);
  const [recording, setRecording] = useState(() => engine.recording);
  useEffect(() => {
    const offPlay = engine.subscribePlay((p) => setPlaying(p));
    const id = window.setInterval(() => {
      setRecording(engine.recording);
    }, 200);
    return () => {
      offPlay();
      window.clearInterval(id);
    };
  }, []);
  return { playing, recording };
}

/** Drive a playhead needle via transform — no React re-render of the timeline. */
export function usePlayheadNeedle(
  zoom: number,
  scroller: RefObject<HTMLElement | null>,
  followWhilePlaying = true,
) {
  const ref = useRef<HTMLDivElement>(null);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const followRef = useRef(followWhilePlaying);
  followRef.current = followWhilePlaying;

  useEffect(() => {
    const apply = (t: number) => {
      const node = ref.current;
      if (!node) return;
      const z = zoomRef.current;
      const x = Math.max(0, Number.isFinite(t) ? t : 0) * z;
      node.style.transform = `translate3d(${x}px,0,0)`;
      if (!followRef.current || !engine.playing) return;
      const sc = scroller.current;
      if (!sc) return;
      const view = sc.scrollLeft;
      const w = sc.clientWidth;
      if (x > view + w - 72) sc.scrollLeft = x - w + 110;
    };
    apply(engine.getPlayhead());
    return engine.subscribe(apply);
  }, [scroller]);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const x = Math.max(0, engine.getPlayhead()) * zoom;
    node.style.transform = `translate3d(${x}px,0,0)`;
  }, [zoom]);

  return ref;
}
