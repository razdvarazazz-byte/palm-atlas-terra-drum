//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CXvI0vo-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/extract",
			"/mix/$projectId"
		],
		preloads: ["/assets/index-HshKkjpc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-HshKkjpc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-2DgMZb_r.js",
			"/assets/projects-wkYlIYrJ.js",
			"/assets/volume-2-DMAN_jFI.js"
		]
	},
	"/extract": {
		filePath: "/workspace/src/routes/extract.tsx",
		children: void 0,
		preloads: [
			"/assets/extract-vrQubaTH.js",
			"/assets/key-CYoPA7cO.js",
			"/assets/projects-wkYlIYrJ.js"
		]
	},
	"/mix/$projectId": {
		filePath: "/workspace/src/routes/mix.$projectId.tsx",
		children: void 0,
		preloads: [
			"/assets/mix._projectId-B54qNUpl.js",
			"/assets/key-CYoPA7cO.js",
			"/assets/projects-wkYlIYrJ.js",
			"/assets/volume-2-DMAN_jFI.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
